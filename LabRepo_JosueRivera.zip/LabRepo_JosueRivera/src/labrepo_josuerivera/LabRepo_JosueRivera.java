/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package labrepo_josuerivera;
import java.util.Scanner;
import java.util.Random;
/**
 *
 * @author josue
 */
public class LabRepo_JosueRivera {
static Scanner sc = new Scanner(System.in);
static Scanner cs = new Scanner(System.in);
static Random rand = new Random();
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("/////menu/////");
        System.out.println("1.Dungeons and Dragons ");
        System.out.println("2.Laberinto ");
        System.out.println("3. salir");
        int opcion = sc.nextInt();
        while (opcion <1 || opcion > 3){
            System.out.println("error, vuelva a introducir su opcion");
            opcion = sc.nextInt();
        }
        while(opcion == 1|| opcion == 2){
            switch (opcion){
                case 1:
                    int puntos_de_vida = 0;
                    int energia = 0;
                    System.out.println("introduce un caracter"+"\n"+"1. caballero(C)"+"\n"+"2. mago(M)");
                    char character = cs.next().charAt(0);
                    while(character != 'M' && character != 'C'){
                        System.out.println("Error, no existe un personaje con ese icono"+"\n"+"introduce un caracter"+"\n"+"1. caballero(C)"+"\n"+"2. mago(M)");
                        character = cs.next().charAt(0);
                    }
                    if(character == 'M'){
                        puntos_de_vida = 150;
                        energia = 230;
                        System.out.println("Usted eligio mago!"+"\n"+"puntos de vida: "+puntos_de_vida+"\n"+"Energia: "+energia);
                    }
                    else{
                        puntos_de_vida = 250;
                        energia = 50;
                        System.out.println("Usted eligio caballero!"+"\n"+"puntos de vida: "+puntos_de_vida+"\n"+"Energia: "+energia);
                    }
                    char [][] Tablero = new char [10][10];
                    
                    Tablero = llenar_matriz(Tablero);
                    Tablero[0][0] = character;
                    imprimir_mat(Tablero);
                     int cont = 0;
                    int movimiento = 0;
                    while(true){
                        System.out.println("presione cualquier tecla para continuar:");
                        char move = cs.next().charAt(0);
                        System.out.println("mueva el dado");
                        int dado = rand.nextInt((16 - 1)+1)+1;
                        System.out.println("te salio "+dado+" en el dado");
                        movimiento += dado;
                        if (movimiento > Tablero.length - 1){
                            movimiento = movimiento - 9;
                            if (movimiento > Tablero.length - 1){
                                movimiento = movimiento - 9;
                                cont++;
                            }
                            cont++;
                        }
                        if (cont > Tablero.length -1){
                            Tablero=llenar_matriz(Tablero);
                            Tablero[Tablero.length-1][Tablero.length-1]=character;
                            imprimir_mat(Tablero);
                            System.out.println("Felicidades terminaste la Dungeon con vida");
                            break;
                        }
                        if (Tablero [cont][movimiento] == '♡'){
                            System.out.println("encontraste un cofre con 20 de vida");
                            puntos_de_vida += 20;
                        }
                        else if (Tablero [cont][movimiento] == '▲'){
                            System.out.println("encontraste un cofre con 5 de energia");
                            energia += 5;
                        }
                        if (dado % 2 != 0){
                            if (cont < 3){
                                int prob = rand.nextInt((100 - 0)+1);
                                if (prob > 50){
                                    System.out.println("se encontro a 2 dragones "
                                            + "y logro ganar, pierde 10 puntos de energia");
                                    energia -= 10;
                                }
                                else{
                                    System.out.println("se encontro a 2 dragones"
                                            + " y no logro ganar, pierde 50 puntos de vida");
                                    puntos_de_vida -= 50;
                                }
                            }
                             else if ((cont>= 3) && (cont < 6)){
                                int prob = rand.nextInt((100 - 0)+1);
                                if (prob > 50){
                                    System.out.println("se encontro a 3 dragones "
                                            + "y logro ganar, pierde 15 puntos de energia");
                                    energia -= 15;
                                }
                                else{
                                    System.out.println("se encontro a 3 dragones"
                                            + " y no logro ganar, pierde 75 puntos de vida");
                                    puntos_de_vida -= 75;
                                }
                            }
                             else if ((cont >= 6)&&(cont < 9)){
                                 int prob = rand.nextInt((100 - 0)+1);
                                if (prob > 50){
                                    System.out.println("se encontro a 4 dragones "
                                            + "y logro ganar, pierde 20 puntos de energia");
                                    energia -= 20;
                                }
                                else{
                                    System.out.println("se encontro a 4 dragones"
                                            + " y no logro ganar, pierde 100 puntos de vida");
                                    puntos_de_vida -= 100;
                                }
                             }
                             else if(cont == 9){
                                 int prob = rand.nextInt((100 - 0)+1);
                                if (prob > 50){
                                    System.out.println("se encontro a 5 dragones "
                                            + "y logro ganar, pierde 25 puntos de energia");
                                    energia -= 25;
                                }
                                else{
                                    System.out.println("se encontro a 5 dragones"
                                            + " y no logro ganar, pierde  puntos de vida");
                                    puntos_de_vida -= 125;
                                }
                             }
                            
                        }
                        if (puntos_de_vida <= 0){
                            System.out.println("El juego termino tu personaje tiene 0 puntos de vida");
                            break;
                        }
                        System.out.println("vida:"+puntos_de_vida);
                        System.out.println("Energia:"+energia);
                        
                        Tablero=llenar_matriz(Tablero);
                        Tablero[cont][movimiento]= character;
                        imprimir_mat(Tablero);
                    }
                    //movimiento_tablero(Tablero, character);
                    break;
                    
                case 2:
                    int x = 1;
                    int y = 1;
                    char personaje = 'C';
                    char [][] mesa = new char [8][10];
                    mesa = llenar_mesa(mesa);
                    while(true){
                        mesa [x][y] = personaje;
                        imprimir2_mat(mesa);
                        System.out.println(" Ingrese un movimiento (w,a,s,d):");
                        char move2 = cs.next().charAt(0);
                        while(move2 != 'w' && move2 != 'W'&& move2 != 'a'&& move2 != 'A'&& move2 != 's'&& move2 != 'S'&& move2 != 'd'&& move2 != 'D'){
                            System.out.println("error, movimiento no valido, ingrese una opcion valida (w,a,s,d):");
                            move2 = cs.next().charAt(0);
                        }
                        if (move2 == 'w' || move2 == 'W'){
                            x -= 1;
                            if (mesa [x][y] == '#'){
                                System.out.println("Movimiento no valido, vuelva a ingresar una opcion");
                                x += 1;
                                continue;
                            }
                            mesa[x][y] = personaje;
                            
                            
                        }
                        if (move2 == 's' || move2 == 'S'){
                            x+= 1;
                            if (mesa [x][y] == '#'){
                                System.out.println("Movimiento no valido, vuelva a ingresar una opcion");
                                x -= 1;
                                continue;
                            }
                            mesa[x][y] = personaje;
                            
                        }
                        if (move2 == 'a' || move2 == 'A'){
                            y -= 1;
                            if (mesa [x][y] == '#'){
                                System.out.println("Movimiento no valido, vuelva a ingresar una opcion");
                                y += 1;
                                continue;
                            }
                            mesa[x][y] = personaje;
                            
                        }
                        if (move2 == 'd'||move2 == 'D'){
                            y += 1;
                            if (mesa [x][y] == '#'){
                                System.out.println("Movimiento no valido, vuelva a ingresar una opcion");
                                y -= 1;
                                continue;
                            }
                            mesa[x][y] = personaje;
                            
                        }
                        if (mesa [2][9] == personaje){
                            
                            mesa = llenar_mesa(mesa);
                            imprimir2_mat(mesa);
                            System.out.println("Encontraste la salida");
                            break;
                        }
                        
                        mesa = llenar_mesa(mesa);
                    }
                    
                    break;
            }
            System.out.println("/////menu/////");
            System.out.println("1.Dungeons and Dragons ");
            System.out.println("2. laberinto");
            System.out.println("3. salir");
            opcion = sc.nextInt();
        }
    }
    public static void imprimir2_mat(char [][] x){
        for (int i = 0; i < x.length; i++) {
            for (int j = 0; j < x[i].length; j++) {
                System.out.print(x[i][j]);
            }
            System.out.println("");
        }
    }
    public static char [][] llenar_mesa(char [][] x){
        for (int i = 0; i < x.length; i++) {
            for (int j = 0; j < x[i].length; j++) {
                if (i == 1){
                    if (j == 2 || j == 6 || j == 7){
                        x[i][j] = '#';
                    }
                }
                if (i == 2){
                    if (j == 2 || j== 4|| j == 5 || j == 6){
                        x[i][j] = '#';
                    }
                }
                if (i == 3){
                    if (j == 2 || j == 6 || j == 8){
                        x[i][j] = '#';
                    }
                }
                if (i == 4){
                    if (j == 4 || j == 6){
                        x[i][j] = '#';
                    }
                }
                if (i == 5){
                    if (j == 2 || j == 4|| j == 6 || j == 7){
                        x[i][j] = '#';
                    }
                }
                if (i == 6){
                    if (j == 2 || j == 4){
                        x[i][j] = '#';
                    }
                }
                if ((i == 0 || j == 0 || i == 7 || j == 9)&&!(i == 2 && j == 9)){
                    x[i][j] = '#';
                }
                else if(x[i][j] != '#'){
                    x[i][j] = ' ';
                }
            }
        }
        return x;
    }
    public static void movimiento_tablero(char [][] x, char p){
        int cont = 0;
        int movimiento = 0;
        while(true){
            System.out.println("presione cualquier tecla para continuar:");
            char move = cs.next().charAt(0);
            System.out.println("mueva el dado");
            int dado = rand.nextInt((16 - 1)+1)+1;
            movimiento += dado;
            if (movimiento > x.length - 1){
                movimiento = movimiento - 10;
                cont++;
            }
            if (cont > x.length -1){
                x=llenar_matriz(x);
                x[x.length-1][x.length-1]=p;
                imprimir_mat(x);
                break;
            }
            x=llenar_matriz(x);
            x[cont][movimiento]=p;
            imprimir_mat(x);
        }
    }
    public static char [][] llenar_matriz(char [][] x){
        
        for (int i = 0; i < x.length; i++) {
            for (int j = 0; j < x.length; j++) {
                if (i % 2 == 0){
                    if (((j % 3 == 0) && j != 0 ) || j == 1){
                        x[i][j] = '♡';
                    }else{
                        x[i][j] = '-';
                    }
                }
                else{
                    x[i][j] = '-';
                }
                if ((j == i || i+j == x.length - 1) &&(x[i][j] != '♡')&&(( i != 9 || j!= 9 )&&(i != 0 || i != 0))){
                    x[i][j] = '▲';
                }
            }
        }
        
        return x;
    }
    public static void imprimir_mat(char [][] x){
        for (int i = 0; i < x.length; i++) {
            for (int j = 0; j < x.length; j++) {
                System.out.print(x[i][j]+" ");
                
            }
            System.out.println("");
            
        }
    }
    
}




